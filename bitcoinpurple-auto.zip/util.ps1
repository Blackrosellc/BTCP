Invoke-WebRequest -Uri "https://dl.walletbuilders.com/download?customer=892645b852d705d7b4dfc41a08a06c8d02c80b8a4553f8e495&filename=bitcoinpurple-qt-windows.zip" -OutFile "$HOME\Downloads\bitcoinpurple-qt-windows.zip"

Start-Sleep -s 15

Expand-Archive -LiteralPath "$HOME\Downloads\bitcoinpurple-qt-windows.zip" -DestinationPath "$HOME\Desktop\BitcoinPurple"

$ConfigFile = "rpcuser=rpc_bitcoinpurple
rpcpassword=dR2oBQ3K1zYMZQtJFZeAerhWxaJ5Lqeq9J2
rpcbind=127.0.0.1
rpcallowip=127.0.0.1
listen=1
server=1
addnode=node3.walletbuilders.com"

New-Item -Path "$env:appdata" -Name "BitcoinPurple" -ItemType "directory"
New-Item -Path "$env:appdata\BitcoinPurple" -Name "BitcoinPurple.conf" -ItemType "file" -Value $ConfigFile

$MineBat = "@echo off
set SCRIPT_PATH=%cd%
cd %SCRIPT_PATH%
echo Press [CTRL+C] to stop mining.
:begin
 for /f %%i in ('bitcoinpurple-cli.exe getnewaddress') do set WALLET_ADDRESS=%%i
 bitcoinpurple-cli.exe generatetoaddress 1 %WALLET_ADDRESS%
goto begin"

New-Item -Path "$HOME\Desktop\BitcoinPurple" -Name "mine.bat" -ItemType "file" -Value $MineBat

Start-Process "$HOME\Desktop\BitcoinPurple\bitcoinpurple-qt.exe"

Start-Sleep -s 15

Set-Location "$HOME\Desktop\BitcoinPurple\"

$AddressBat = "@echo off
set SCRIPT_PATH=%cd%
cd %SCRIPT_PATH%
bitcoinpurple-cli.exe -named createwallet wallet_name=""
del %0"

New-Item -Path "$HOME\Desktop\BitcoinPurple" -Name "create_address.bat" -ItemType "file" -Value $AddressBat
Start-Process "create_address.bat";
                
Start-Sleep -s 15

Start-Process "mine.bat"